/*
 * DCMotor_interface.h
 *
 *  Created on: Nov 27, 2023
 *      Author: omnia sherief
 */

#ifndef DCMOTOR_INTERFACE_H_
#define DCMOTOR_INTERFACE_H_

//void DcMotor_Init();
void DcMotor_CW();
void DcMotor_CCW();
void DcMotor_Stop();

#endif /* DCMOTOR_INTERFACE_H_ */
