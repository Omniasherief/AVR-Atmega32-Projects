/*
 * DCMotor_cfg.h
 *
 *  Created on: Nov 27, 2023
 *      Author: omnia sherief
 */

#ifndef DCMOTOR_CFG_H_
#define DCMOTOR_CFG_H_

#define DC_Motor_Port   DIO_u8PORTC //DIO_u8PORTA
#define DC_Motor_Pin1   DIO_u8PIN3            //DIO_u8PIN0
#define DC_Motor_Pin2   DIO_u8PIN4            //DIO_u8PIN1
#endif /* DCMOTOR_CFG_H_ */
