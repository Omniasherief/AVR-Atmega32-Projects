/*
 * DCMotor_prv.h
 *
 *  Created on: Nov 27, 2023
 *      Author: omnia sherief
 */

#ifndef DCMOTOR_PRV_H_
#define DCMOTOR_PRV_H_



#endif /* DCMOTOR_PRV_H_ */
