#ifndef KPD_PRV_H
#define KPD_PRV_H

#define COL_NUM			4u
#define ROW_NUM			4u

#endif
