#ifndef KPD_INTERFACE_H
#define KPD_INTERFACE_H

uint8 KPD_u8GetPressedKey(void);

#endif