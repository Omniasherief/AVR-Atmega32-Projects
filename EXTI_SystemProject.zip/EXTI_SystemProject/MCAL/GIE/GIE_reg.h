/*
 * GIE_reg.h
 *
 *  Created on: Dec 6, 2023
 *      Author: omnia sherief
 */

#ifndef GIE_REG_H_
#define GIE_REG_H_

#define SREG      *((colatile uint8)ox5F)   /*status regidtor*/
#define  SREG_I   7u  //interrupt bit
#endif /* GIE_REG_H_ */
