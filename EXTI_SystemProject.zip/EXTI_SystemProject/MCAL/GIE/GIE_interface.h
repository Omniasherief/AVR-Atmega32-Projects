/*
 * GIE_interface.h
 *
 *  Created on: Dec 6, 2023
 *      Author: omnia sherief
 */

#ifndef GIE_INTERFACE_H_
#define GIE_INTERFACE_H_

void GIE_voidEnableGlobal(void);
void GIE_voidDisableGlobal (void);


#endif /* GIE_INTERFACE_H_ */
