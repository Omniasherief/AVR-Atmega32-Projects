#ifndef PORT_INTEFACE_H
#define  PORT_INTEFACE_H

void PORT_voidInit(void);
#endif