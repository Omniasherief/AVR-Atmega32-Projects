#ifndef ERRTYPES_H
#define ERRTYPES_H
#define NULL 0
#define OK 0
#define NOK 1
#define NULL_PTR_ERR 2





#endif
